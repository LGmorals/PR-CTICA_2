/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Dell Inspiron 15
 */
public class Registro implements Serializable {

    String Vehiculo;
    int distancia;
    String Monto;
    Date FechaHoraCreacion;
    Date FechaHoraEntrega;

    public Registro(String Vehiculo, int distancia, String Precio, Date FechaHoraCreacion, Date FechaHoraEntrega) {
        this.Vehiculo = Vehiculo;
        this.distancia = distancia;
        this.Monto = Monto;
        this.FechaHoraCreacion = FechaHoraCreacion;
        this.FechaHoraEntrega = FechaHoraEntrega;
    }

    public static void Serializacion(JTable THistorial) {
        DefaultTableModel modelo = (DefaultTableModel) THistorial.getModel();
        int rowCount = modelo.getRowCount();
        Registro[] registros = new Registro[rowCount];

        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        try {
            for (int i = 0; i < rowCount; i++) {
                String vehiculo = modelo.getValueAt(i, 0).toString();
                int distancia = Integer.parseInt(modelo.getValueAt(i, 1).toString());
                String monto = modelo.getValueAt(i, 2).toString();
                String fechaCreacionString = modelo.getValueAt(i, 3).toString();
                String fechaEntregaString = modelo.getValueAt(i, 4).toString();

                Date fechaCreacion = formatoFecha.parse(fechaCreacionString);
                Date fechaEntrega = formatoFecha.parse(fechaEntregaString);

                Registro registro = new Registro(vehiculo, distancia, monto, fechaCreacion, fechaEntrega);
                registros[i] = registro;
            }

            FileOutputStream archivo = new FileOutputStream("./Respaldo.txt");
            ObjectOutputStream salida = new ObjectOutputStream(archivo);
            salida.writeObject(registros);
            salida.close();
            archivo.close();
            System.out.println("Se ha respaldado su programa en: Respaldo.txt");
        } catch (Exception e) {
            System.out.println(e);
            // Si ocurre un error, puedes manejarlo aquí asignando un valor por defecto a las fechas
            // Date fechaCreacion = new Date();
            // Date fechaEntrega = new Date();
        }

    }

    public static void DeSerializacion() {
        Registro[] registros;
        try {
            FileInputStream archivo = new FileInputStream("./Respaldo.txt");
            ObjectInputStream entrada = new ObjectInputStream(archivo);
            registros = (Registro[]) entrada.readObject();
            entrada.close();
            archivo.close();

            FileWriter fileWriter = new FileWriter("./Respaldo.txt", true); // Abre el archivo en modo de adición (append)
            PrintWriter printWriter = new PrintWriter(fileWriter);

            // Mostrar registros cargados en el archivo
            for (Registro registro : registros) {
                printWriter.println(registro.Vehiculo + " " + registro.distancia + " " + registro.Monto + " " + registro.FechaHoraCreacion + " " + registro.FechaHoraEntrega);
            }

            printWriter.close();
            fileWriter.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}