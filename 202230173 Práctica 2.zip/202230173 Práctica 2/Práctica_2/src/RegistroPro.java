/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Dell Inspiron 15
 */
public class RegistroPro implements Serializable {

    String MenuSeleccionado;
    String Precio;

    public RegistroPro(String Producto, String Precio) {
        this.MenuSeleccionado = Producto;
        this.Precio = Precio;
    }

    public static void Serializacion(JTable Pedidos) {
        DefaultTableModel modelo = (DefaultTableModel) Pedidos.getModel();
        int rowCount = modelo.getRowCount();
        RegistroPro[] registros = new RegistroPro[rowCount];

        try {
            for (int i = 0; i < rowCount; i++) {
                String Producto = modelo.getValueAt(i, 0).toString();
                String Precio = modelo.getValueAt(i, 1).toString();

                RegistroPro registro = new RegistroPro(Producto, Precio);
                registros[i] = registro;
            }

            FileOutputStream archivo = new FileOutputStream("./RespaldoProductos.txt", false);
            ObjectOutputStream salida = new ObjectOutputStream(archivo);
            salida.writeObject(registros);
            salida.close();
            archivo.close();
            System.out.println("Se ha respaldado su programa en: Respaldo.txt");
        } catch (Exception e) {
            System.out.println(e);
            // Si ocurre un error, puedes manejarlo aquí asignando un valor por defecto a las fechas
            // Date fechaCreacion = new Date();
            // Date fechaEntrega = new Date();
        }
        JOptionPane.showMessageDialog(null, "Serializado Exitosamente", "Correcto", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void DeSerializacion() {
        RegistroPro[] registros;
        try {
            FileInputStream archivo = new FileInputStream("./RespaldoProductos.txt");
            ObjectInputStream entrada = new ObjectInputStream(archivo);
            registros = (RegistroPro[]) entrada.readObject();
            entrada.close();
            archivo.close();

            FileWriter fileWriter = new FileWriter("./RespaldoDeserializadoProductos.txt", false); // Abre el archivo en modo de adición (append)
            PrintWriter printWriter = new PrintWriter(fileWriter);

            // Mostrar registros cargados en el archivo
            for (RegistroPro registro : registros) {
                printWriter.println(registro.MenuSeleccionado + " " + registro.Precio);
            }

            printWriter.close();
            fileWriter.close();

            System.out.println("Se ha deserializado su programa en: RespaldoDeserializadoProductos.txt");

        } catch (Exception e) {
            System.out.println(e);
        }
        JOptionPane.showMessageDialog(null, "DeSerializado Exitosamente", "Correcto", JOptionPane.INFORMATION_MESSAGE);
    }

                            
}