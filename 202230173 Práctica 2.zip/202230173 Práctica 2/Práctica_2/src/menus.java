/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dell Inspiron 15
 */
public class menus {
    public String MenúSeleccionado;
    public String Precio;

public menus(String MenúSeleccionado, String Precio) {
  this.MenúSeleccionado = MenúSeleccionado;
  this.Precio = Precio;
} 
}